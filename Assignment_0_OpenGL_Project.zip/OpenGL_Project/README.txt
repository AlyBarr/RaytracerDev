Name of Student: Alyssa Barrientos

Collaborators: 

Professor Garcia-Gomez
They had helped me with setting up the environment as the laptop I am using did not have drivers listed as well as installing specifications with Visual Studio Code.

References:
Rpxomi - online source (rpxomi.github.io)
Their "How to include GLAD" showed me how to fix my file structure to include Glad.h as both the main.cpp and glad.c needed to follow our folder structure such as being "#include "include/glad/glad.h"".

Problems:
No Known Problems

Comments: 
The Assignment was not too difficult, however, as most of the issues were troubleshooting and setting up a new OPENGL environment. It created a fun and interesting affect and had examples in the code. I do want to mess around a little after submitting. (Maybe I will show you if I am able to make something before next class.)

