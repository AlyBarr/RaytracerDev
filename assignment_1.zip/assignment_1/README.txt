Name of Student: Alyssa Barrientos

Collaborators: 

References:

Problems:
A few problems with rotation and smooth transition of color for extra credit. Could not go on to the next step for camera.

Comments: 
The Assignment was not too difficult, however, as most of the issues were troubleshooting and setting up the cube.

