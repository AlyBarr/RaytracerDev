Name of Student: Alyssa Barrientos

1. Did you collaborate with anyone in the class? If so, let us know who you talked to and what sort of help you gave or received.

    I did not collaborate with anyone in the class. I would have appreciated the chance to attend the workshop for additional help, but unfortunately, I was unable to.

2. Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? Please provide a list.

    References:

        penGL Documentation: Used for learning about how to set up OpenGL for rendering shapes.

        https://www.khronos.org/opengl/

    GLM Documentation: Used for handling 3D vectors and transformations.

        https://github.com/g-truc/glm

    Professor's Notes and Slides: Provided a basic understanding of how to approach rendering 3D shapes and handling transformations.

3. Are there any known problems with your code? If so, please provide a list and, if possible, describe what you think the cause is and how you might fix them if you had more time or motivation. This is very important, as we’re much more likely to assign partial credit if you help us understand what’s going on.

    Yes, there are a few known issues:

    Surface Rendering Issues: When I try to generate B-splines or surfaces (e.g., a generalized cylinder or surface revolution), nothing loads correctly, and the program crashes. It seems that when the circle.swp is not loaded or handled properly, the program shuts down without rendering anything.

    B-spline Handling: I don't fully understand how B-splines should be calculated and how they should be used to generate surfaces. The calculations around converting control points to Bezier curves or B-splines are unclear, which makes it difficult for me to process them and generate the desired surfaces.

    Missing or Incorrect Data in Evaluation: For curves and surfaces, certain points (e.g., tangents, normals) are being computed but might be missing or incorrect, leading to rendering errors or crashes.


    How I might fix them if I had more time or motivation:

    Debugging the Surface Generation: If I had more time, I would focus on isolating the code that handles B-splines and surface generation. I'd start by simplifying the input and ensuring that control points are correctly passed and transformed through the algorithms.

    Revising B-spline Handling: I would go back to the basics of B-splines and Bezier curves, studying their implementation in-depth. I'd also review how to convert B-spline control points to Bezier curves (as I suspect the conversion is not done correctly).

    Working with Tangents, Normals, and Binormals: I'd revisit the logic for calculating tangents, normals, and binormals and ensure that they are correctly computed and normalized for each point along the curve or surface.


4. Got any comments about this assignment that you’d like to share? Was it too long? Too hard? Were the requirements unclear? Did you have fun, or did you hate it? Did you learn something, or was it a total waste of your time? Feel free to be brutally honest; we promise we won’t take it personally.

    Difficulty Level: The assignment was challenging, especially the part about understanding the mathematical concepts of B-splines and surfaces. It felt like I wasn’t able to fully grasp how these concepts work in practice.

    Time Constraints: I tried to split some time throughout the break and to step away when I got stuck to clear my head. However, it wasn’t sufficient for me to both understand the concepts and implement them correctly.

    Understanding Concepts: I did not fully understand how to properly implement the B-spline or surface generation parts. If I had more time to review the material and attend workshops or seek assistance, I believe I could make progress.

    Overall Experience: While I found the concepts interesting, the complexity of the assignment and the difficulty in understanding key principles made it feel overwhelming. I would have liked more clarification or additional resources to help clarify these concepts, especially around surface generation.