#include "Sphere.h"

#include <vector>
#include <cmath>

Sphere::Sphere(float x, float y, float z, float scale, int colorIndex, int id)
    : Shape(x, y, z, scale, colorIndex, id), VAO(0), VBO(0), EBO(0) {
    shapeType = "Sphere";  // Set the type as "Sphere"
    
    setupSphere(); // Initialize OpenGL objects for the sphere
}

Sphere::~Sphere() {
    // Cleanup OpenGL resources
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
}

void Sphere::setupSphere() {
    vertices = {
        // Top part (Front left to front right)
        glm::vec3(0.0f,  1.0f,  0.0f),   // 0: Top center
        glm::vec3(-0.5f,  0.5f,  0.5f),   // 1: Left top front
        glm::vec3( 0.5f,  0.5f,  0.5f),   // 2: Right top front

        // Middle part (Middle left to middle right)
        glm::vec3(-1.0f,  0.0f,  0.0f),   // 3: Left middle front
        glm::vec3( 1.0f,  0.0f,  0.0f),   // 4: Right middle front

        // Bottom part (Bottom left to bottom right)
        glm::vec3(-0.8f, -1.0f,  0.0f),   // 5: Left bottom front
        glm::vec3( 0.8f, -1.0f,  0.0f),   // 6: Right bottom front

        // Top back (Back left to back right)
        glm::vec3(-0.5f,  0.5f, -0.5f),   // 7: Left top back
        glm::vec3( 0.5f,  0.5f, -0.5f),   // 8: Right top back

        // Bottom back (Back left to back right)
        glm::vec3(-1.0f,  0.0f, -1.0f),   // 9: Left middle back
        glm::vec3( 1.0f,  0.0f, -1.0f),   // 10: Right middle back
        glm::vec3(-0.8f, -1.0f, -0.5f),   // 11: Left bottom back
        glm::vec3( 0.8f, -1.0f, -0.5f)    // 12: Right bottom back
    };

    // Define normals (pointing along the Z-axis for simplicity)
    normals = {
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 0
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 1
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 2
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 3
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 4
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 5
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 6
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 7
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 8
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 9
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 10
        glm::vec3(0.0f, 0.0f, 1.0f),  // Normal for vertex 11
        glm::vec3(0.0f, 0.0f, 1.0f)   // Normal for vertex 12
    };

    // Define faces (triangles connecting the vertices)
    faces = {
        // Front faces
        {0, 1, 2},  // Top center -> Left top front -> Right top front
        {1, 3, 5},  // Left top front -> Left middle front -> Left bottom front
        {2, 4, 6},  // Right top front -> Right middle front -> Right bottom front
        {3, 4, 5},  // Left middle front -> Right middle front -> Left bottom front
        {4, 5, 6},  // Right middle front -> Left bottom front -> Right bottom front

        // Back faces
        {0, 7, 8},  // Top center -> Left top back -> Right top back
        {7, 9, 11}, // Left top back -> Left middle back -> Left bottom back
        {8, 10, 12},// Right top back -> Right middle back -> Right bottom back
        {9, 10, 11},// Left middle back -> Right middle back -> Left bottom back
        {10, 11, 12},// Right middle back -> Left bottom back -> Right bottom back

        // Side faces (connecting front to back)
        {1, 7, 3},  // Left top front -> Left top back -> Left middle front
        {2, 8, 4},  // Right top front -> Right top back -> Right middle front
        {5, 11, 3}, // Left bottom front -> Left bottom back -> Left middle front
        {6, 12, 4}, // Right bottom front -> Right bottom back -> Right middle front
    };

    // Prepare OpenGL buffers using the populated attributes
    std::vector<float> vertexData;
    std::vector<unsigned int> indexData;

    glm::vec3 color = (colorIndex == 31) 
        ? glm::vec3(
            customColor[0], 
            customColor[1], 
            customColor[2]
        )
        : glm::vec3(
            colorPresets[colorIndex].color[0], 
            colorPresets[colorIndex].color[1], 
            colorPresets[colorIndex].color[2]
         );

    for (const auto& face : faces) {
        for (int vertexIndex : face) {
            const glm::vec3& position = vertices[vertexIndex];
            const glm::vec3& normal = normals[vertexIndex];

            vertexData.insert(vertexData.end(), {position.x, position.y, position.z});
            vertexData.insert(vertexData.end(), {normal.x, normal.y, normal.z});
            vertexData.insert(vertexData.end(), {color.r, color.g, color.b});
        }
    }

    for (size_t i = 0; i < faces.size(); ++i) {
        indexData.insert(indexData.end(), {i * 3, i * 3 + 1, i * 3 + 2});
    }

    // Create and bind VAO, VBO, and EBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertexData.size() * sizeof(float), vertexData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexData.size() * sizeof(unsigned int), indexData.data(), GL_STATIC_DRAW);

    // Configure vertex attributes
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0); // Position
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float))); // Normal
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(6 * sizeof(float))); // Color
    glEnableVertexAttribArray(2);

    glBindVertexArray(0); // Unbind VAO
}

void Sphere::draw(GLuint shaderProgram) {

    // Use the shader program
    glUseProgram(shaderProgram);
    
    // Enable lighting for the cube
    GLint lightingLoc = glGetUniformLocation(shaderProgram, "useLighting");
    if (lightingLoc != -1) {
        glUniform1i(lightingLoc, 1); // Enable lighting for the cube
    }

    // Apply transformations and pass to the shader
    applyTransform(shaderProgram);

    // Pass material properties
    GLint colorLoc = glGetUniformLocation(shaderProgram, "material.color");
    if (colorLoc != -1) {
        glUniform3fv(colorLoc, 1, (colorIndex == 31) ? customColor : colorPresets[colorIndex].color);
    }

    // Render the cube
    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(faces.size() * 3), GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);

    // Disable lighting after drawing the sphere (for axis rendering)
    if (lightingLoc != -1) {
        glUniform1i(lightingLoc, 0);
    }

}
