#include "Surface.h"

namespace {
// Check if the profile curve is flat on the xy-plane
bool checkFlat(const Curve &profile) {
    for (const auto& p : profile.getControlPoints()) {
        if (p.z != 0.0f) return false;
    }
    return true;
}
}

Surface Surface::makeSurfRev(const Curve& profile, unsigned steps) {

    Surface surface;

    if (!checkFlat(profile)) {
        std::cerr << "surfRev profile curve must be flat on the xy-plane." << std::endl;
        exit(0);
    }

    // 2.4.1 - Create the functionality to process surface revolutions

    // Here you should build the surface.  See Surface.h for details.

    // Create a container to hold the surface's mesh data
    std::vector<glm::vec3> vertices;
    std::vector<std::vector<unsigned>> faces;

    // 2.4.1 - Revolve the profile curve around the z-axis to create the surface
    float angleIncrement = 2 * M_PI / steps;  // Divide 360 degrees by steps

    // Iterate through each control point of the profile
    for (unsigned i = 0; i < profile.getControlPoints().size(); ++i) {
        glm::vec3 profilePoint = profile.getControlPoints()[i];

        // For each point in the profile, rotate it around the z-axis to create vertices
        for (unsigned j = 0; j < steps; ++j) {
            float angle = j * angleIncrement;
            float x = profilePoint.x * cos(angle) - profilePoint.y * sin(angle);
            float y = profilePoint.x * sin(angle) + profilePoint.y * cos(angle);
            float z = profilePoint.z;  // Z remains constant

            // Store the rotated vertex
            vertices.push_back(glm::vec3(x, y, z));

            // Create faces between the generated vertices (not implemented here)
            // You will need to connect these vertices to form triangles or quads.
        }
    }

    // After generating all vertices, you'd need to create faces (triangular or quadrilateral) to complete the mesh
    // For simplicity, let's just print out some of the vertices
    std::cerr << "\t>>> Revolved surface has " << vertices.size() << " vertices." << std::endl;

    surface.setVertices(vertices);
    surface.setFaces(faces);


    std::cerr << "\t>>> makeSurfRev called (but not implemented).\n\t>>> Returning empty surface." << std::endl;

    return surface;
}


Surface Surface::makeGenCyl(const Curve& profile, const Curve& sweep) {

    Surface surface;

    if (!checkFlat(profile)) {
        std::cerr << "genCyl profile curve must be flat on the xy-plane." << std::endl;
        exit(0);
    }

    // 2.4.2 - Create the functionality to process surface sweeps

    // Here you should build the surface.  See surf.h for details.
    // Create a container to hold the surface's mesh data
    std::vector<glm::vec3> vertices;
    std::vector<std::vector<unsigned>> faces;

    // 2.4.2 - Sweep the profile along the sweep curve to create the surface
    for (unsigned i = 0; i < sweep.getControlPoints().size(); ++i) {
        glm::vec3 sweepPoint = sweep.getControlPoints()[i];

        // For each point in the sweep curve, move the profile along this point
        for (unsigned j = 0; j < profile.getControlPoints().size(); ++j) {
            glm::vec3 profilePoint = profile.getControlPoints()[j];

            // Move the profile point along the sweep curve
            glm::vec3 sweptPoint = profilePoint + sweepPoint;

            // Store the swept point as a vertex
            vertices.push_back(sweptPoint);

            // Create faces between the generated vertices (not implemented here)
            // You would need to connect these vertices to form the surface faces.
        }
    }

    // After generating all vertices, you need to create faces (triangular or quadrilateral) to complete the mesh
    // For simplicity, let's just print out some of the vertices
    std::cerr << "\t>>> Swept surface has " << vertices.size() << " vertices." << std::endl;

    surface.setVertices(vertices);
    surface.setFaces(faces);


    std::cerr << "\t>>> makeGenCyl called (but not implemented).\n\t>>> Returning empty surface." << std::endl;

    return surface;

}


