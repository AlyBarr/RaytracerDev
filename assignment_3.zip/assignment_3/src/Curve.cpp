#include "Curve.h"
#include <glm/gtx/string_cast.hpp>
#include <iostream>

// Helper function to calculate the binomial coefficient
unsigned binomial(unsigned n, unsigned k) {
    if (k > n) return 0;
    if (k == 0 || k == n) return 1;

    // Apply Pascal's rule to compute binomial coefficient
    unsigned result = 1;
    for (unsigned i = 1; i <= k; ++i) {
        result *= n - (k - i);
        result /= i;
    }
    return result;
}

Curve::Curve(const std::string& name, unsigned steps, const std::string& curveType)
    : name(name), steps(steps), curveType(curveType) {}

// Get curve name
const std::string& Curve::getName() const {
    return name;
}

// Set control points
void Curve::setControlPoints(const std::vector<glm::vec3>& cps) {
    controlPoints = cps;
}

// Get control points
const std::vector<glm::vec3>& Curve::getControlPoints() const {
    return controlPoints;
}

// Getter for curvePoints
const CurvePoints& Curve::getCurvePoints() const {
    return curvePoints;
}

// Setter for curvePoints
void Curve::setCurvePoints(const CurvePoints& points) {
    curvePoints = points;
}


// Set steps
void Curve::setSteps(unsigned steps) {
    this->steps = steps;
}

// Get steps
unsigned Curve::getSteps() const {
    return steps;
}

// Set curve type
void Curve::setCurveType(const std::string& type) {
    curveType = type;
}

// Get curve type
const std::string& Curve::getCurveType() const {
    return curveType;
}


// Function to evaluate Bezier curve points
CurvePoints Curve::evalBezier(const std::vector<glm::vec3>& P, unsigned steps) {


    CurvePoints curve;

    // Check if number of points are required for Bezier
    if (P.size() < 4 || P.size() % 3 != 1) {
        std::cerr << "evalBezier must be called with 3n+1 control points." << std::endl;
        exit(0);
    }

    // 2.3.1 - Create the functionality to process Bezier control points

    // TODO:
    // You should implement this function so that it returns a Curve
    // (e.g., a vector< CurvePoint >).  The variable "steps" tells you
    // the number of points to generate on each piece of the spline.
    // At least, that's how the sample solution is implemented and how
    // the SWP files are written.  But you are free to interpret this
    // variable however you want, so long as you can control the
    // "resolution" of the discretized spline curve with it.

    // Make sure that this function computes all the appropriate
    // Vector3fs for each CurvePoint: V,T,N,B.
    // [NBT] should be unit and orthogonal.

    // Also note that you may assume that all Bezier curves that you
    // receive have G1 continuity.  Otherwise, the TNB will not be
    // be defined at points where this does not hold.

    // Calculate Bezier curve points
    for (unsigned i = 0; i <= steps; ++i) {
        float t = static_cast<float>(i) / steps;
        glm::vec3 point(0.0f);
        unsigned n = P.size() - 1;

        // Calculate the point on the Bezier curve using Bernstein basis
        for (unsigned j = 0; j <= n; ++j) {
            float coeff = binomial(n, j) * std::pow(1.0f - t, n - j) * std::pow(t, j);
            point += coeff * P[j];
        }

        // Compute tangent by differentiating the Bezier curve (approximating by finite differences)
        glm::vec3 tangent = glm::vec3(0.0f);
        if (i < steps - 1) {
            tangent = glm::normalize(curve[i + 1].point - point);
        } else if (i > 0) {
            tangent = glm::normalize(point - curve[i - 1].point);
        }

        // Compute normal and binormal (simplified for now)
        glm::vec3 normal = glm::normalize(glm::cross(tangent, glm::vec3(1.0f, 0.0f, 0.0f)));  // Approximate normal
        glm::vec3 binormal = glm::normalize(glm::cross(tangent, normal));  // Approximate binormal

        // Store the computed point, tangent, normal, and binormal
        curve.push_back({point, tangent, normal, binormal});
    }

    std::cerr << "\t>>> evalBezier has been called with the following input:" << std::endl;

    std::cerr << "\t>>> Control points (type vector< glm::vec3 >): "<< std::endl;
    for( unsigned i = 0; i < P.size(); ++i )
    {
        std::cerr << "\t>>> (" << P[i].x << ", " << P[i].y << ", " << P[i].z << ")" << std::endl;
    }

    std::cerr << "\t>>> Steps (type steps): " << steps << std::endl;
    std::cerr << "\t>>> Returning empty curve." << std::endl;

    // Right now this will just return this empty curve.

    return curve;
}



CurvePoints Curve::evalBspline(const std::vector<glm::vec3>& P, unsigned steps) {

    CurvePoints curve;

    // Check if number of points are required for Bspline
    if (P.size() < 4) {
        std::cerr << "evalBspline must be called with 4 or more control points." << std::endl;
        exit(0);
    }

    // 2.3.2 - Create the functionality to process BSpline control points

    // TODO:
    // It is suggested that you implement this function by changing
    // basis from B-spline to Bezier.  That way, you can just call
    // your evalBezier function.    
    
    // Convert B-spline control points to Bezier control points (simplified example)
    std::vector<glm::vec3> bezierControlPoints;
    for (size_t i = 1; i < P.size() - 1; ++i) {
        glm::vec3 p0 = P[i - 1];
        glm::vec3 p1 = P[i];
        glm::vec3 p2 = P[i + 1];
        glm::vec3 p3 = P[i + 2];

        // Convert B-spline to Bezier control points
        bezierControlPoints.push_back(p0);
        bezierControlPoints.push_back(p1);
        bezierControlPoints.push_back(p2);
        bezierControlPoints.push_back(p3);
    }

    std::cerr << "\t>>> evalBSpline has been called with the following input:" << std::endl;

    std::cerr << "\t>>> Control points (type vector< glm::vec3 >): "<< std::endl;
    for( unsigned i = 0; i < P.size(); ++i )
    {
        std::cerr << "\t>>> (" << P[i].x << ", " << P[i].y << ", " << P[i].z << ")" << std::endl;
    }

    std::cerr << "\t>>> Steps (type steps): " << steps << std::endl;
    std::cerr << "\t>>> Returning empty curve." << std::endl;

    // Return an empty curve right now.
    //return evalBezier(bezierControlPoints, steps);
    return curve;
}



// Function to evaluate circle points
CurvePoints Curve::evalCircle(float radius, unsigned steps) {

    CurvePoints circlePoints;
    
    // 2.3.3 - Create the functionality to process Circles based on radius and steps

    // Based on how you evaluated Bezier and B-spline curves, you will calcuate and return a curve
    // that will create a circle. The curve will contain the same CurvePoint structure: V,T,N,B.

    // Parametric equation for the circle
    for (unsigned i = 0; i < steps; ++i) {
        float t = static_cast<float>(i) / steps;
        float theta = t * 2.0f * M_PI;  // Full circle

        // Parametric equation for the circle (in the XY plane)
        glm::vec3 point = glm::vec3(radius * std::cos(theta), radius * std::sin(theta), 0.0f);

        // Tangent (derivative of the position)
        glm::vec3 tangent = glm::vec3(-radius * std::sin(theta), radius * std::cos(theta), 0.0f);
        glm::vec3 normal = glm::normalize(glm::cross(tangent, glm::vec3(0.0f, 0.0f, 1.0f)));  // Assuming the circle lies in the XY plane
        glm::vec3 binormal = glm::normalize(glm::cross(tangent, normal));

        // Store the computed point, tangent, normal, and binormal
        circlePoints.push_back({point, tangent, normal, binormal});
    }

    std::cerr << "\t>>> evalCircle has been called with the following input:" << std::endl;

    std::cerr << "\t>>> Radius: "<< radius << std::endl;
    std::cerr << "\t>>> Steps (type steps): " << steps << std::endl;
    std::cerr << "\t>>> Returning empty curve." << std::endl;













    // Return an empty curve right now.
    
    return circlePoints;
}
