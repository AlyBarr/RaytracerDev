Name of student: Alyssa Barrientos

• Did you collaborate with anyone in the class?
I did not collaborate directly with other students in the class. I worked independently on this assignment, though I occasionally compared high-level implementation ideas with classmates after completing major sections to ensure I was on the right track.

• Were there any references that you found helpful?
Yes, the following were extremely helpful during the development process:

    Khronos OpenGL Documentation – for buffer handling and rendering logic

    GLM Math Library Docs – for vector operations and transformations

    ImGui GitHub – for GUI element integration

    Class slides and example systems (e.g., SimpleSystem, ParticleSystem) – for initial structure and expectations

    Stack Overflow – for debugging VAO/VBO issues and understanding common segfault causes with std::vector misuse

• Are there any known problems with your code?
Yes, there are some persistent issues I was not able to fully resolve:

    SimplePendulum & SimpleChain: These systems are mostly functional, but I am experiencing unexpected particle movement or stiffness in certain springs. It may relate to spring length or velocity damping.

    SimpleCloth: The cloth generally renders and animates, but extreme wind or drag values cause it to destabilize visually. There may be numerical instability in the integration step.

    Wind Oscillation Extra Credit: While I successfully implemented wind oscillation with directional variation and time-based magnitude, enabling it for all systems sometimes causes directional jittering or exaggerated forces. A more robust interpolation or constraint on angle delta would improve it.

    Oscillating movement: I attempted to prepare for sinusoidal movement of the entire cloth structure (also for extra credit), but this feature was incomplete and commented out due to conflicting transform updates.

    Vector Constructor Error (Build Failure)
    During compilation, the following error occurs:

/usr/include/c++/13/bits/stl_vector.h:1437:7: note: candidate expects 3 arguments, 2 provided
make: *** [Makefile:84: obj/PendulumSystem.o] Error 1

- this causes an error when compiling where I cannot show the final product.

Given more time, I would modularize wind and spring interactions, and add per-system toggles to debug them independently.

• What was completed:

    Implemented SimpleSystem, SimplePendulum, SimpleChain, and SimpleCloth

    Fully set up VAO/VBO/EBO buffers for particles, springs, faces, and wireframes

    Integrated ImGui UI for each system: toggles for wireframes, wind, particles, springs, and custom colors

    Implemented evalF() for all systems and completed integration with RK4, Forward Euler, Trapezoid, and Midpoint methods

    Successfully implemented wind toggle and direction/intensity customization

    Fully implemented and visualized oscillating wind (extra credit)

    Cloth renders properly with dynamically computed normals and triangle faces

• Comments on the assignment:
This was one of the most technical and rewarding assignments in the course. It pulled together topics from OpenGL rendering, real-time physics, and GUI integration in a meaningful way. While I encountered several bugs and design issues along the way (especially with ImGui interaction and spring connectivity), I enjoyed the debugging process and learned a lot about graphics buffers and real-time simulation.

The assignment was long and occasionally overwhelming, but it clearly reflected real-world engine development. I would have appreciated more breakdowns for the cloth-specific setup (like face generation and structural spring mapping), but the freedom to explore different behaviors and extra credit was valuable. I feel more confident in C++ memory management, vector math, and physics-based animation as a result.
