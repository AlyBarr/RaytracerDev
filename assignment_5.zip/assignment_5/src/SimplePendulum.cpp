#include "SimplePendulum.h"
#include <vector>

SimplePendulum::SimplePendulum(float x, float y, float z, float scale, int colorIndex, int id, float length, float mass)
    : PendulumSystem(x, y, z, scale, colorIndex, id, 2), m_length(length), m_mass(mass) {

    shapeType = "Simple Pendulum";  // Set the type as "Simple Pendulum"
    m_length = length;
    m_mass = mass;

    // TODO: Set up the initial state

    // Initial particle positions and velocities
    glm::vec3 p0 = glm::vec3(0.0f, 0.0f, 0.0f);       // Fixed point
    glm::vec3 v0 = glm::vec3(0.0f, 0.0f, 0.0f);       // No velocity

    glm::vec3 p1 = glm::vec3(0.0f, -m_length, 0.0f);  // Hanging mass
    glm::vec3 v1 = glm::vec3(0.0f, 0.0f, 0.0f);       // No initial velocity

    // Add to system state
    m_state.push_back(p0); m_state.push_back(v0);
    m_state.push_back(p1); m_state.push_back(v1);

    m_initialState = m_state;

    // Visualization particles
    particles.clear();
    particles.emplace_back(p0, 1.0f);
    particles.emplace_back(p1, 1.0f);

    // Springs: (index0, index1, restLength, stiffness)
    springs.clear();
    springs.emplace_back(glm::vec4(0, 1, m_length, 50.0f));  // Adjust stiffness if needed

    // No faces for this system
    faces.clear();


    setupParticles(particles, springs, faces);
    
}

SimplePendulum::~SimplePendulum() {

}



