#include "SimpleCloth.h"
#include <vector>

SimpleCloth::SimpleCloth(float x, float y, float z, float scale, int colorIndex, int id, float length, float mass, int clothSize)
    : PendulumSystem(x, y, z, scale, colorIndex, id, clothSize * clothSize) {

    shapeType = "Simple Cloth";  // Set the type as "Simple Cloth"
    m_length = length;
    m_mass = mass;

    // TODO: Set up the initial state
    m_state.clear();
    particles.clear();
    springs.clear();
    faces.clear();

    int n = clothSize;
    float spacing = m_length; // distance between adjacent particles
    float stiffness = 50.0f;  // adjust as needed

    // 1. Add particles
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            glm::vec3 pos(x + i * spacing, y - j * spacing, z); // grid layout
            glm::vec3 vel(0.0f);

            m_state.push_back(pos);
            m_state.push_back(vel);

            particles.emplace_back(glm::vec4(pos, 1.0f));
        }
    }

    // Helper to get linear index
    auto idx = [n](int i, int j) { return j * n + i; };

    // 2. Add structural springs (horizontal & vertical)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            if (i < n - 1)  // right neighbor
                springs.emplace_back(glm::vec4(idx(i, j), idx(i + 1, j), spacing, stiffness));
            if (j < n - 1)  // below neighbor
                springs.emplace_back(glm::vec4(idx(i, j), idx(i, j + 1), spacing, stiffness));
        }
    }

    // 3. Add shear springs (diagonals)
    for (int j = 0; j < n - 1; ++j) {
        for (int i = 0; i < n - 1; ++i) {
            springs.emplace_back(glm::vec4(idx(i, j), idx(i + 1, j + 1), spacing * std::sqrt(2), stiffness));
            springs.emplace_back(glm::vec4(idx(i + 1, j), idx(i, j + 1), spacing * std::sqrt(2), stiffness));
        }
    }

    // 4. Add flexion springs (skip one)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            if (i < n - 2)
                springs.emplace_back(glm::vec4(idx(i, j), idx(i + 2, j), 2 * spacing, stiffness));
            if (j < n - 2)
                springs.emplace_back(glm::vec4(idx(i, j), idx(i, j + 2), 2 * spacing, stiffness));
        }
    }

    m_initialState = m_state;



    setupParticles(particles, springs, faces);

}


