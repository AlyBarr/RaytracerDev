#include "SimpleChain.h"
#include <vector>

SimpleChain::SimpleChain(float x, float y, float z, float scale, int colorIndex, int id, float length, float mass)
    : PendulumSystem(x, y, z, scale, colorIndex, id, 4) {  // 2 particles: anchor and bob 

    shapeType = "Simple Chain";  // Set the type as "Simple Chain"
    m_length = length;
    m_mass = mass;

    // TODO: Set up the initial state
    // Initial positions (straight vertical chain)
    m_state.clear();
    particles.clear();
    springs.clear();
    faces.clear(); // no faces for chain

    for (int i = 0; i < 4; ++i) {
        glm::vec3 pos(0.0f, -i * m_length, 0.0f);
        glm::vec3 vel(0.0f, 0.0f, 0.0f);

        m_state.push_back(pos);
        m_state.push_back(vel);

        particles.emplace_back(glm::vec4(pos, 1.0f));
    }

    // Create springs between adjacent particles
    float stiffness = 50.0f; // or tweak as needed
    for (int i = 0; i < 3; ++i) {
        springs.emplace_back(glm::vec4(i, i + 1, m_length, stiffness));
    }

    m_initialState = m_state;


    setupParticles(particles, springs, faces);

}


