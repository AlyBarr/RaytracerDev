#include "PendulumSystem.h"
#include <cmath> // For math functions like sin, cos, sqrt
#include "glad/glad.h"
#include <GLFW/glfw3.h>
#include <iostream>

// Oscillating wind support
#include <cmath>
#include <ctime>


PendulumSystem::PendulumSystem(float x, float y, float z, float scale, int colorIndex, int id, int numParticles)
    : ParticleSystem(x, y, z, scale, colorIndex, id), windDirection(1.0f, 0.0f, 0.0f), windIntensity(1.0f) { 

    m_numParticles = numParticles;
    m_gravity = -9.81f;
    m_drag = 1.0f;
    m_mass = 1.0f;

    wireframe_ON = false;
    wind_ON = false;
    sinusoidMove_ON = false;
    faces_ON = true;

    particles_ON = false;
    structSprings_ON = false;

    isCloth = false;

    degree = 0;

    float radius = 0.025f;
    int sectorCount = 8;
    int stackCount = 8;

    // Particle sphere rendering
    VAO, VBO, EBO = 0;
    springVAO, springVBO = 0;
    wireVAO, wireVBO = 0;
    faceVAO, faceVBO, faceEBO = 0;

    generateUnitSphereMesh( radius, sectorCount, stackCount);
}

PendulumSystem::~PendulumSystem() {
    if (VAO) glDeleteVertexArrays(1, &VAO);
    if (VBO) glDeleteBuffers(1, &VBO);
    if (EBO) glDeleteBuffers(1, &EBO);
    if (springVAO) glDeleteVertexArrays(1, &springVAO);
    if (springVBO) glDeleteBuffers(1, &springVBO);
    if (wireVAO) glDeleteVertexArrays(1, &wireVAO);
    if (wireVBO) glDeleteBuffers(1, &wireVBO);
    if (faceVAO) glDeleteVertexArrays(1, &faceVAO);
    if (faceVBO) glDeleteBuffers(1, &faceVBO);
    if (faceEBO) glDeleteBuffers(1, &faceEBO);
}


void PendulumSystem::generateUnitSphereMesh(float radius, int sectorCount, int stackCount) {
    unitSphereVertices.clear();
    unitSphereNormals.clear();
    unitSphereIndices.clear();

    for (int i = 0; i <= stackCount; ++i) {
        float stackAngle = glm::pi<float>() / 2 - i * glm::pi<float>() / stackCount;
        float xy = radius * cos(stackAngle);
        float z = radius * sin(stackAngle);

        for (int j = 0; j <= sectorCount; ++j) {
            float sectorAngle = j * 2 * glm::pi<float>() / sectorCount;
            float x = xy * cos(sectorAngle);
            float y = xy * sin(sectorAngle);
            glm::vec3 pos(x, y, z);
            glm::vec3 normal = glm::normalize(pos);
            unitSphereVertices.push_back(pos);
            unitSphereNormals.push_back(normal);
        }
    }

    for (int i = 0; i < stackCount; ++i) {
        for (int j = 0; j < sectorCount; ++j) {
            int first = i * (sectorCount + 1) + j;
            int second = first + sectorCount + 1;

            unitSphereIndices.push_back(first);
            unitSphereIndices.push_back(second);
            unitSphereIndices.push_back(first + 1);

            unitSphereIndices.push_back(second);
            unitSphereIndices.push_back(second + 1);
            unitSphereIndices.push_back(first + 1);
        }
    }
}


// Add to PendulumSystem::update or a new method:
void PendulumSystem::updateWindOscillation(float dt) {
    if (oscillatingWind_ON) {
        windOscillationTime += dt;
    }
}

void PendulumSystem::setupParticles(const std::vector<glm::vec4>& myParticles, 
                                    const std::vector<glm::vec4>& mySprings,
                                    const std::vector<glm::vec3>& myFaces) {

    particleVertices.clear();
    particleIndices.clear();
    springVertices.clear();
    
    
    particles = myParticles;
    springs = mySprings;
    faces = myFaces;

    m_state.clear();

    // TODO: Build your initial particles and velocities for your pendulum system and 
    // populate it back to m_state. Build your buffers in particleVertices and 
    // particleIndices
    
    for (const auto& p : particles) {
        glm::vec3 pos = glm::vec3(p);
        glm::vec3 vel(0.0f);
        m_state.push_back(pos);
        m_state.push_back(vel);

        for (const auto& v : unitSphereVertices) {
            glm::vec3 transformed = v + pos;
            glm::vec3 normal = glm::normalize(v);
            particleVertices.insert(particleVertices.end(), { transformed.x, transformed.y, transformed.z });
            particleVertices.insert(particleVertices.end(), { normal.x, normal.y, normal.z });
        }
    }

    for (size_t i = 0; i < particles.size(); ++i) {
        for (unsigned int idx : unitSphereIndices) {
            particleIndices.push_back(static_cast<unsigned int>(i * unitSphereVertices.size() + idx));
        }
    }

    // Build the buffers for the particles

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, particleVertices.size() * sizeof(float), particleVertices.data(), GL_DYNAMIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, particleIndices.size() * sizeof(unsigned int), particleIndices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
    
    setupSprings();
    setupFaces();
    setupWireframe();

}

void PendulumSystem::setupSprings() {

    springVertices.clear();


    // TODO: Build your initial spring pairs positions for your pendulum system and 
    // build your buffers in springVertices. This helps to draw all spring structures between 
    // particles
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Build the buffers for the springs
    
    
    for (const auto& spring : springs) {
        int i0 = static_cast<int>(spring[0]);
        int i1 = static_cast<int>(spring[1]);

        glm::vec3 p0 = m_state[2 * i0]; // particle positions
        glm::vec3 p1 = m_state[2 * i1];

        springVertices.insert(springVertices.end(), { p0.x, p0.y, p0.z });
        springVertices.insert(springVertices.end(), { p1.x, p1.y, p1.z });
    }
    
    glGenVertexArrays(1, &springVAO);
    glGenBuffers(1, &springVBO);

    glBindVertexArray(springVAO);
    glBindBuffer(GL_ARRAY_BUFFER, springVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * springs.size(), nullptr, GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);

    updateSprings();

}


void PendulumSystem::setupWireframe() {
    wireVertices.clear();

    // TODO: Build your initial spring pairs positions for your pendulum system wireframe and 
    // build your buffers in wireVertices. This helps to draw spring structures between 
    // particles. The wireframe are only the structural springs that are horizontally and vertically
    // linking particles. This is only used in SimpleCloth

























    // Generate VAO and VBO if not already created
    glGenVertexArrays(1, &wireVAO);
    glGenBuffers(1, &wireVBO);

    // Bind VAO and VBO
    glBindVertexArray(wireVAO);
    glBindBuffer(GL_ARRAY_BUFFER, wireVBO);

    // Upload wireframe vertex data
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * wireVertices.size(), nullptr, GL_DYNAMIC_DRAW);

    
    // Position attribute (3 floats per vertex)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0); // Unbind VAO
    
    updateWireframe();    
   
}




void PendulumSystem::setupFaces() {

    faceVertices.clear();
    faceIndices.clear();

    // TODO: Build your initial face vertices positions and face indices  for your pendulum system used in SimpleCloth. 
    // This creates the triangles and creates the  surface of the cloth. For now, depending on your initial position of 
    // the cloth, just use an axis-aligned normal vector for the normal. This is only used in SimpleCloth

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    

    // Build the buffers for the particles

    glGenVertexArrays(1, &faceVAO);
    glGenBuffers(1, &faceVBO);
    glGenBuffers(1, &faceEBO);

    glBindVertexArray(faceVAO);

    glBindBuffer(GL_ARRAY_BUFFER, faceVBO);
    glBufferData(GL_ARRAY_BUFFER, faceVertices.size() * sizeof(float), faceVertices.data(), GL_DYNAMIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, faceEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, faceIndices.size() * sizeof(unsigned int), faceIndices.data(), GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    updateFaces();    

}


void PendulumSystem::updateParticles() {

    particleVertices.clear(); // Reset

    // TODO: Build your updates to your particles postion and velocities for your 
    // pendulum system. Update your buffers in particleVertices and 
    // particleIndices

    for (int p = 0; p < m_numParticles; ++p) {
        glm::vec3 center = m_state[2 * p];
        for (const auto& v : unitSphereVertices) {
            glm::vec3 transformed = v + center;
            glm::vec3 normal = glm::normalize(v);
            particleVertices.insert(particleVertices.end(), { transformed.x, transformed.y, transformed.z });
            particleVertices.insert(particleVertices.end(), { normal.x, normal.y, normal.z });
        }
    }

    // Update VBO
    
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * particleVertices.size(), particleVertices.data(), GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

}


void PendulumSystem::updateSprings() {

    springVertices.clear();

    // TODO: Build your updated spring pairs positions for your pendulum system and 
    // build your buffers in springVertices. This helps to draw all spring structures between 
    // particles

    for (const auto& spring : springs) {
        int i0 = static_cast<int>(spring[0]);
        int i1 = static_cast<int>(spring[1]);
        glm::vec3 p0 = m_state[2 * i0];
        glm::vec3 p1 = m_state[2 * i1];
        springVertices.insert(springVertices.end(), { p0.x, p0.y, p0.z });
        springVertices.insert(springVertices.end(), { p1.x, p1.y, p1.z });
    }

    // Update VBO
    
    glBindBuffer(GL_ARRAY_BUFFER, springVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * springVertices.size(), springVertices.data(), GL_DYNAMIC_DRAW); 
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void PendulumSystem::updateWireframe() {

    wireVertices.clear();


    // TODO: Build your updated spring pairs positions for your pendulum system wireframe and 
    // build your buffers in wireVertices. This helps to draw spring structures between 
    // particles. The wireframe are only the structural springs that are horizontally and vertically
    // linking particles. This is only used in SimpleCloth
    
    for (const auto& spring : springs) {
        int i0 = static_cast<int>(spring[0]);
        int i1 = static_cast<int>(spring[1]);
        if (abs(i0 - i1) == 1 || abs(i0 - i1) == clothSize) { // horizontal or vertical
            glm::vec3 p0 = m_state[2 * i0];
            glm::vec3 p1 = m_state[2 * i1];
            wireVertices.insert(wireVertices.end(), { p0.x, p0.y, p0.z });
            wireVertices.insert(wireVertices.end(), { p1.x, p1.y, p1.z });
        }
    }

    // Update VBO
    
    glBindBuffer(GL_ARRAY_BUFFER, wireVBO);
    glBufferData(GL_ARRAY_BUFFER, wireVertices.size() * sizeof(float), wireVertices.data(), GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}





void PendulumSystem::updateFaces() {

    faceVertices.clear();
    faceIndices.clear();

    // TODO: Build your updated face vertices positions and face indices  for your pendulum system used in SimpleCloth. 
    // This creates the triangles and creates the  surface of the cloth. This is only used in SimpleCloth
    //
    // Here you would need to calculate normals. Since our shader uses a per-vertex normal input, you would need to look
    // at all adjacent faces to a vertex, calculate the faces normals, and accumulate that by summing their vectors. At 
    // the end, this creates very smooth surface through interpolation.   

    if (!isCloth) return;
    for (int j = 0; j < clothSize - 1; ++j) {
        for (int i = 0; i < clothSize - 1; ++i) {
            int idx0 = j * clothSize + i;
            int idx1 = j * clothSize + (i + 1);
            int idx2 = (j + 1) * clothSize + i;
            int idx3 = (j + 1) * clothSize + (i + 1);
            // Triangle 1: idx0, idx2, idx1
            // Triangle 2: idx1, idx2, idx3
            glm::vec3 p0 = m_state[2 * idx0];
            glm::vec3 p1 = m_state[2 * idx1];
            glm::vec3 p2 = m_state[2 * idx2];
            glm::vec3 p3 = m_state[2 * idx3];
            glm::vec3 n1 = glm::normalize(glm::cross(p1 - p0, p2 - p0));
            glm::vec3 n2 = glm::normalize(glm::cross(p2 - p1, p3 - p1));

            for (auto [p, n] : { std::pair(p0,n1), std::pair(p2,n1), std::pair(p1,n1) })
                faceVertices.insert(faceVertices.end(), { p.x, p.y, p.z, n.x, n.y, n.z });
            for (auto [p, n] : { std::pair(p1,n2), std::pair(p2,n2), std::pair(p3,n2) })
                faceVertices.insert(faceVertices.end(), { p.x, p.y, p.z, n.x, n.y, n.z });

            unsigned int startIdx = static_cast<unsigned int>(faceVertices.size() / 6) - 6;
            for (int k = 0; k < 6; ++k) faceIndices.push_back(startIdx + k);
        }
    }


    // Update VBO
    
    glBindBuffer(GL_ARRAY_BUFFER, faceVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * faceVertices.size(), faceVertices.data(), GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}




// TODO: implement evalF
// for a given state, evaluate f(X,t)

std::vector<glm::vec3> PendulumSystem::evalF(const std::vector<glm::vec3>& state) {

    std::vector<glm::vec3> f(state.size(), glm::vec3(0.0f, 0.0f, 0.0f));

    // TODO: implement evalF
    // for a given state, evaluate f(X,t). Make sure this works for simplePendulum, simpleChain
    // and simpleCloth
    glm::vec3 totalForce(0.0f, 0.0f, 0.0f);


    for (int i = 0; i < m_numParticles; ++i) {

        // Fix particle 0 (anchor)
        if (i == 0) {
            f[2 * i] = glm::vec3(0.0f);
            f[2 * i + 1] = glm::vec3(0.0f);
            continue;
        }

        if (isCloth && i < clothSize) {
            f[2 * i] = glm::vec3(0.0f);
            f[2 * i + 1] = glm::vec3(0.0f);
            continue;
        }

        glm::vec3 pos = state[2 * i];
        glm::vec3 vel = state[2 * i + 1];
        glm::vec3 totalForce(0.0f);

        if (isCloth && wind_ON) {
            glm::vec3 dynamicWind = windDirection * windIntensity;
            if (oscillatingWind_ON) {
                float t = windOscillationTime;
                float magnitude = 1.0f + 0.5f * sin(t);
                glm::vec3 newDir = glm::normalize(glm::vec3(cos(t * 0.5f), 0.0f, sin(t * 0.5f)));
                dynamicWind = newDir * windIntensity * magnitude;
            }
            totalForce += dynamicWind;
        }


        // Gravity
        totalForce += glm::vec3(0.0f, m_mass * m_gravity, 0.0f);

        // Drag
        totalForce += -m_drag * vel;

        // Spring force
        for (const glm::vec4& spring : springs) {
            int i0 = static_cast<int>(spring[0]);
            int i1 = static_cast<int>(spring[1]);
            float restLen = spring[2];
            float k = spring[3];

            if (i == i0 || i == i1) {
                int j = (i == i0) ? i1 : i0;
                glm::vec3 p_i = state[2 * i];
                glm::vec3 p_j = state[2 * j];

                glm::vec3 d = p_i - p_j;
                float length = glm::length(d);
                if (length != 0.0f) {
                    glm::vec3 direction = d / length;
                    glm::vec3 springForce = -k * (length - restLen) * direction;
                    totalForce += springForce;
                }
            }
        }

        glm::vec3 acceleration = totalForce / m_mass;

        // Fill derivative vector
        f[2 * i] = vel;             // dx/dt = v
        f[2 * i + 1] = acceleration; // dv/dt = a
    }

    return f;
}


// NOTE: The following flags are available to integrate into your code. Feel free to use them, as they are tied into the Imgui interface.
// We recommend you take a look at the interface so you can see what is available to you for each particle system.


// Enable wind
void PendulumSystem::enableWind() { wind_ON = true; }

// Disable wind
void PendulumSystem::disableWind() { wind_ON = false; }

// Get wind status
bool PendulumSystem::getWind() const{ return wind_ON; }

// Set wind direction
void PendulumSystem::setWindDirection(const glm::vec3& direction) {
    windDirection = glm::normalize(direction);
}

// Set wind intensity
void PendulumSystem::setWindIntensity(float intensity) {
    windIntensity = intensity;
}

// Get wind direction
glm::vec3 PendulumSystem::getWindDirection() const {
    return windDirection;
}

// Get wind intensity
float PendulumSystem::getWindIntensity() const {
    return windIntensity;
}

// Movement utilities
void PendulumSystem::enableMovement() { sinusoidMove_ON = true; }
void PendulumSystem::disableMovement() { sinusoidMove_ON = false; }
bool PendulumSystem::getMovement() const { return sinusoidMove_ON; }

// Wireframe utilities
void PendulumSystem::enableWireframe() { wireframe_ON = true; faces_ON = false; }
void PendulumSystem::disableWireframe() { wireframe_ON = false; faces_ON = true; }
bool PendulumSystem::getWireframe() const { return wireframe_ON; }

// Particles utilities
void PendulumSystem::enableParticles() { particles_ON = true; }
void PendulumSystem::disableParticles() { particles_ON = false; }
bool PendulumSystem::getParticles() const { return particles_ON; }

// Structural springs utilities
void PendulumSystem::enableStructSprings() { structSprings_ON = true; }
void PendulumSystem::disableStructSprings() { structSprings_ON = false; }
bool PendulumSystem::getStructSprings() const { return structSprings_ON; }

void PendulumSystem::setMass(float mass) { m_mass = mass; }
float PendulumSystem::getMass() const { return m_mass; }


void PendulumSystem::reset() {
    // Reset the state of the pendulum using the parent class's reset method
    ParticleSystem::reset();
    
    m_state = m_initialState;  // Restore positions and velocities
    updateParticles();         // Update buffers
    updateSprings();
    updateWireframe();
    updateFaces();
}

void PendulumSystem::draw(GLuint shaderProgram) {

    updateSprings();
    updateWireframe();
    updateFaces(); // optional

    // Use the shader program
    glUseProgram(shaderProgram);
    
    // Enable lighting for the cube
    GLint lightingLoc = glGetUniformLocation(shaderProgram, "useLighting");
    if (lightingLoc != -1) {
        glUniform1i(lightingLoc, 1); // Enable lighting for the pendulum
    }
    
    applyTransform(shaderProgram);

    // Set material color in shader
    GLint colorLoc = glGetUniformLocation(shaderProgram, "material.color");
    if (colorLoc != -1) {
        glUniform3fv(colorLoc, 1, (colorIndex == 31) ? customColor : colorPresets[colorIndex].color);
    }

    // Draw Faces (as triangles)
    
    if (faces_ON) {
    
        // Set material color in shader
        GLint colorLoc = glGetUniformLocation(shaderProgram, "material.color");
        if (colorLoc != -1) {
            glUniform3fv(colorLoc, 1, (colorIndex == 31) ? customColor : colorPresets[colorIndex].color);
        }
        
        glBindVertexArray(faceVAO);
        glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(faceIndices.size()), GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
            
    }
    

    // Wireframe

    if (wireframe_ON){

        // Draw Particles if enabled
        if (particles_ON) {
        
            GLint colorLoc = glGetUniformLocation(shaderProgram, "material.color");
            if (colorLoc != -1) {
                glUniform3f(colorLoc, 1.0f, 1.0f, 1.0f); // white lines
            }
            
            glBindVertexArray(VAO);
            glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(particleIndices.size()), GL_UNSIGNED_INT, 0);
            glBindVertexArray(0);
        }
        
            // Draw Structural Springs (as lines)
        if (structSprings_ON) {
        
            // Disable lighting in shader
            
            GLint lightingLoc = glGetUniformLocation(shaderProgram, "useLighting");
            if (lightingLoc != -1) {
                glUniform1i(lightingLoc, 1); // Disable lighting
            }
            
            glBindVertexArray(springVAO);
            glLineWidth(2.0f);
            glDrawArrays(GL_LINES, 0, static_cast<GLsizei>(springVertices.size() / 3));
            glBindVertexArray(0);

        } else {
        
            // Disable lighting in shader
            
            GLint lightingLoc = glGetUniformLocation(shaderProgram, "useLighting");
            if (lightingLoc != -1) {
                glUniform1i(lightingLoc, 1); // Disable lighting
            }
            
            glBindVertexArray(wireVAO);
            glLineWidth(2.0f);
            glDrawArrays(GL_LINES, 0, static_cast<GLsizei>(wireVertices.size() / 3));
            glBindVertexArray(0);
        
        }


    }
    
}

