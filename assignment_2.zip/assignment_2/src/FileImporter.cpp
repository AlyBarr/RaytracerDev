#include "FileImporter.h"


std::string FileImporter::getExecutableDirectory() {
    char buffer[MAX_PATH];
    if (getcwd(buffer, sizeof(buffer))) {
        return std::string(buffer);
    }
    return "";
}

// Function to import a selected obj file
int FileImporter::importObjFile(ShapeManager& shapeManager) {

    std::string execDir = getExecutableDirectory();
    
    if (!execDir.empty()) {

        // Assuming you want to set the default path to a "data" folder relative to the executable
        std::string defaultPath = execDir + "/data/obj/*.obj";  // Linux/Mac
        // std::string defaultPath = execDir + "\\data";        // Windows

	// Filter for obj files
	const char* fileFilters[] = {"*.obj"};
	
        // Open file chooser dialog for selecting an obj file	
        const char* selectedFile = tinyfd_openFileDialog(
            "Select an OBJ file",
            defaultPath.c_str(),  // Default relative path
            1,                    // Number of filters
            fileFilters,          // Filters array
            "OBJ Files (*.obj)",  // Filter description
            0                     // Allow multiple selection (0 = no, 1 = yes)
        );

	if (!selectedFile) {
	    std::cerr << "File selection cancelled or failed." << std::endl;
	    return 0;
        }

	// Get the shape type from the filename without the extension
        std::string newShapeType = extractShapeType(selectedFile);
        
        newShapeType[0] = std::toupper(newShapeType[0]);
        for (size_t i = 1; i < newShapeType.length(); ++i) {
            newShapeType[i] = std::tolower(newShapeType[i]);
        }

        std::vector<glm::vec3> vertices;
        std::vector<glm::vec3> normals;
        std::vector<std::vector<int>> faces;

// 2.4 - This is where you will load the OBJ content of your shape and parse out the data.
//       This is the standard open source structure for 3D Model files contained in .obj files.
//       Not all obj files are compatible, but to slight differences, but most should work. 
//       You should be able to read the data selected from the file chooser in the above code,
//       and populate the vertices, normals, and faces vectors. 















// ***********************************************************

	// Create the new ImportShape and populate it
	ImportShape* newShape = new ImportShape(0.0f, 0.0f, 0.0f, 1.0f, 1, shapeManager.incrementShapeCounter());
	newShape->setVertices(vertices);
	newShape->setNormals(normals);
	newShape->setFaces(faces);	
	newShape->setupShape();
	
	// Add importedShape to your list of shapes or render it directly
	shapeManager.addShape(newShape);
	shapeManager.setSelectedShapeByLastAdded();  // Select the last shape added
	shapeManager.getSelectedShape()->setShapeType(newShapeType);

    }
  
    return 1;
    
}


// Extract shape type from file name
std::string FileImporter::extractShapeType(const std::string& filename) {
    size_t lastSlash = filename.find_last_of("/\\");
    size_t lastDot = filename.find_last_of('.');

    if (lastSlash == std::string::npos) {
        lastSlash = 0;
    } else {
        lastSlash += 1;
    }

    if (lastDot == std::string::npos || lastDot < lastSlash) {
        lastDot = filename.size();
    }

    return filename.substr(lastSlash, lastDot - lastSlash);
}

