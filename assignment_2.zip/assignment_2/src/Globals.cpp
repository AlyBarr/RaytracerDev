#include "Globals.h"


// Define the custom variables
std::string customShapeName = "Heart";
std::string windowTitle = "3D Shape Editor - Assignment 2 - Alyssa Barrientos";

