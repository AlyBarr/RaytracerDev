README.txt

Name of student:Alyssa Barrientos

Did you collaborate with anyone in the class? If so, let us know who you talked to and what sort of help you gave or received.

I did not collaborate with anyone in the class on this assignment.

Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? Please provide a list.

    OpenGL Documentation: Used for learning about how to set up OpenGL for rendering shapes.

        https://www.khronos.org/opengl/

    GLM Documentation: Used for handling 3D vectors and transformations.

        https://github.com/g-truc/glm

    Professor's Notes and Help: Provided a basic understanding of how to approach rendering 3D shapes and handling transformations.

Are there any known problems with your code? If so, please provide a list and describe what you think the cause is and how you might fix them if you had more time or motivation.

    Broken Teacup Shape:

        The custom shape (teacup) has issues rendering correctly after editing. It is most likely due to a problem in how the shape's vertices or faces were not rendering after implementing another shape.

        Cause: I suspect that the problem occurred when I edited or added new shapes (such as the heart). It might have led to a conflict or bug in how the teacup's vertices and faces are stored or rendered. I may have overwritten or incorrectly connected vertices during the transformation process.

   
    Custom Shape Issues:

        There are some issues with rendering custom 3D shape- my heart, particularly with full shape is incorrect and not being applied as expected.

        Cause: The transformations might not be applied properly in the model-view matrix, or I might be incorrectly updating the model's transformation properties after each update.

    
Got any comments about this assignment that you’d like to share? Was it too long? Too hard? Were the requirements unclear? Did you have fun, or did you hate it? Did you learn something, or was it a total waste of your time? Feel free to be brutally honest; we promise we won’t take it personally.

This assignment was challenging. While it did take a bit longer than I initially expected, I really enjoyed working through the details of 3D rendering and transformations. The most challenging part was working with the custom shape, especially figuring out how to modify vertices and make the shape transform correctly. Although there were a few setbacks sphere, I learned a lot about how OpenGL works, including how to handle 3D models and transformations.

In hindsight, the requirements could have been a bit clearer when it came to troubleshooting custom shapes and transformations. I had some issues with rendering the shapes after editing others, and I spent more time than expected figuring out how to make everything work together smoothly.

Overall, I feel like I gained valuable experience, and the assignment was definitely a great learning opportunity.