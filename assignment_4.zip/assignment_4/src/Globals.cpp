#include "Globals.h"


// Define the custom variables
std::string customShapeName = "Custom Shape";
std::string windowTitle = "CPSC 566 - Assignment 4 - Alyssa Barrientos";
std::vector<std::string> jointName = { "Root", "Chest", "Waist", "Neck", "Right hip", "Right leg", "Right knee", "Right foot", "Left hip", "Left leg", "Left knee", "Left foot", "Right collarbone", "Right shoulder", "Right elbow", "Left collarbone", "Left shoulder", "Left elbow" };
