Name of Student: Alyssa Barrientos

1. Did you collaborate with anyone in the class? If so, let us know who you talked to and what sort of help you gave or received.

    I did not collaborate with anyone in the class. I would have appreciated the chance to attend the workshop for additional help, but unfortunately, I was unable to.

2. Were there any references (books, papers, websites, etc.) that you found particularly helpful for completing your assignment? Please provide a list.

    References:

        OpenGL Documentation: Used for learning about how to set up OpenGL for rendering shapes.

        https://www.khronos.org/opengl/

    GLM Documentation: Used for handling 3D vectors and transformations.

        https://github.com/g-truc/glm

    Professor's Notes and Slides: Provided a basic understanding of how to approach rendering 3D shapes and handling transformations.

3. Are there any known problems with your code? If so, please provide a list and, if possible, describe what you think the cause is and how you might fix them if you had more time or motivation. This is very important, as we’re much more likely to assign partial credit if you help us understand what’s going on.

    Yes, several issues persist in my code, mostly related to the joint and skeleton system, as well as surface generation. The biggest challenge came from working with the joint hierarchy and transforms.

    As the joints don't seem to be affected by the change and reset whenever I try to change them.
    
    BindWorldToJointTransformRecursive Not Functioning Properly:
    This method failed to load properly, which prevented me from manipulating joints or posing characters as required. The recursive logic in handling joint transformations seemed to either not be updating correctly or not binding the transforms to the mesh. As a result, I was unable to move forward with posing characters or connecting animations.

    Skeleton Complaints and Runtime Errors:
    I encountered multiple errors while trying to load or manipulate skeleton data. The editor would complain about joint hierarchies, and in some cases, crash outright. Debugging was difficult due to the interconnected nature of the joint system, and I was not able to isolate the exact cause in time.

    Joint Hierarchy and Transforms:
    I would spend more time reviewing the recursive functions that bind world transforms to joints. I’d step through the hierarchy and print debug values to ensure that each transform is applied in the correct order and with the correct parent-child relationships.

    Skeleton Debugging:
    I would focus on better understanding how skeleton JSON data is parsed and structured in code, and write validation tools to catch errors in the hierarchy before runtime.
4. Got any comments about this assignment that you’d like to share? Was it too long? Too hard? Were the requirements unclear? Did you have fun, or did you hate it? Did you learn something, or was it a total waste of your time? Feel free to be brutally honest; we promise we won’t take it personally.
This was a very challenging assignment—especially the mathematical and recursive aspects of the skeleton and joint systems. While I found the ideas behind character posing and surface creation exciting, I struggled with the implementation due to the complexity and lack of clarity in certain areas.
What Worked:

    The base framework made sense once I got everything to compile.

    The documentation and examples helped me get started.

What Didn’t:

    Joint transforms and posing were extremely difficult to debug without more visual feedback or detailed walkthroughs.

    Surface generation (especially involving B-splines) was too abstract without additional examples or visual validation tools.

Overall:

I did my best to complete the assignment but fell short in key areas like joint manipulation and surface creation. I wanted to work on the extra credit for posing characters and showcasing a scene, but due to multiple errors and the breakdown of the joint system, I was unable to complete this part. With more time or access to help (such as workshops or debugging walkthroughs), I believe I could have resolved most of the issues.

Still, I found the challenge interesting and learned a lot—even if the results didn’t fully come together in the end.